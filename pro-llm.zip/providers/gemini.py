from typing import List, Dict, Any, Optional
from google import genai
from google.genai import types
from tenacity import retry, wait_exponential, stop_after_attempt

class GeminiClient:
    def __init__(self, api_key: str):
        self.client = genai.Client(api_key=api_key)

    @retry(wait=wait_exponential(multiplier=1, min=1, max=8), stop=stop_after_attempt(3))
    def leader_plan(self, user_prompt: str, system_prompt: str, url_budget: int = 8) -> Dict[str, Any]:
        tools = [
            types.Tool(url_context=types.UrlContext()),
            types.Tool(google_search=types.GoogleSearch())
        ]
        contents = [
            types.Content(role="system", parts=[types.Part.from_text(text=system_prompt)]),
            types.Content(role="user", parts=[types.Part.from_text(text=user_prompt)])
        ]
        cfg = types.GenerateContentConfig(
            tools=tools,
            thinking_config=types.ThinkingConfig(thinking_budget=-1),
            response_mime_type="application/json",
        )
        resp = self.client.models.generate_content(
            model="gemini-2.5-pro",
            contents=contents,
            config=cfg
        )
        # Expect JSON with 'plan'
        text = "".join([p.text for p in resp.candidates[0].content.parts if getattr(p, "text", None)])
        return {"raw": text, "url_context_metadata": getattr(resp.candidates[0], "url_context_metadata", None)}

    @retry(wait=wait_exponential(multiplier=1, min=1, max=8), stop=stop_after_attempt(3))
    def formatter(self, merged_markdown: str, bibliography: List[Dict[str, Any]], target_schema: Dict[str, Any], system_prompt: str) -> Dict[str, Any]:
        contents = [
            types.Content(role="system", parts=[types.Part.from_text(text=system_prompt)]),
            types.Content(role="user", parts=[
                types.Part.from_text(text="merged_draft:\n" + merged_markdown),
                types.Part.from_text(text="bibliography:\n" + str(bibliography)),
                types.Part.from_text(text="target_schema:\n" + str(target_schema)),
            ])
        ]
        cfg = types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_budget=0),
            response_mime_type="application/json",
        )
        resp = self.client.models.generate_content(
            model="gemini-2.5-flash",
            contents=contents,
            config=cfg
        )
        text = "".join([p.text for p in resp.candidates[0].content.parts if getattr(p, "text", None)])
        return {"raw": text}