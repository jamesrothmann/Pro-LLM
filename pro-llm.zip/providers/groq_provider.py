from typing import Dict, Any, List
from groq import Groq
from tenacity import retry, wait_exponential, stop_after_attempt

class GroqClient:
    def __init__(self, api_key: str):
        self.client = Groq(api_key=api_key)

    @retry(wait=wait_exponential(multiplier=1, min=1, max=8), stop=stop_after_attempt(3))
    def worker(self, system_prompt: str, subtask: str, evidence_bundle: str, temperature: float = 0.2) -> Dict[str, Any]:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Subtask:\n{subtask}\n\nEvidence:\n{evidence_bundle}\nReturn JSON only."}
        ]
        completion = self.client.chat.completions.create(
            model="openai/gpt-oss-120b",
            messages=messages,
            temperature=temperature,
            top_p=1,
            max_completion_tokens=4096,
            reasoning_effort="high",
            stream=False,
            response_format={"type": "json_object"}
        )
        return completion.choices[0].message